package com.spring.orm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.dao.StudentDao;
import com.spring.orm.entities.Student;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
//		Student student=new Student(12,"Pranav Kumar","Simhatol");
//		int r=studentDao.insert(student);
//		System.out.println("Done "+r);

		boolean go = true;
		while (go) {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("PRESS 1 ADD NEW STUDENT");
			System.out.println("PRESS 2 FOR DISPLAY ALL STUDENT");
			System.out.println("PRESS 3 FOR GET DETAILS OF SINGLE STUDENT");
			System.out.println("PRESS 4 FOR DELETE STUDENT");
			System.out.println("PRESS 5 FOR UPDATE STUDENT");
			System.out.println("PRESS 6 FOR EXIT");

			try {
				int input = Integer.parseInt(br.readLine());
				switch (input) {
				case 1:
					System.out.println("Enter Student id");
					int uid=Integer.parseInt(br.readLine());
					System.out.println("Enter Student name");
					String sname=br.readLine();
					System.out.println("Enter Student City");
					String scity=br.readLine();
					Student student=new Student(uid,sname,scity);
					int i = studentDao.insert(student);
					System.out.println(i+" Student added");
					System.out.println("*********************************");
					System.out.println();
					break;
				case 2:
					List<Student> list=studentDao.getAllStudent();
					System.out.println("*********************************");
					for(Student s:list)
					{
						System.out.println("Id :"+s.getStudentId()+"\nName :"+s.getStudentName()+"\nCity :"+s.getStudentCity());
						
						System.out.println("-------------------------------");
					}
					System.out.println("**********************************");
					
					break;
				case 3:
					System.out.println("Enter Student id");
					int sid=Integer.parseInt(br.readLine());
					Student s = studentDao.getStudent(sid);
					System.out.println("**********************");
					System.out.println("Id :"+s.getStudentId()+"\nName :"+s.getStudentName()+"\nCity :"+s.getStudentCity());
					System.out.println("***********************");
					break;
				case 4:
					System.out.println("Enter Student id");
					int u1id=Integer.parseInt(br.readLine());
					studentDao.deleteStudent(u1id);
					System.out.println("Student Deleted");
					break;
				case 5:
					
					break;
				case 6:
					go=false;
					break;

				}
			} catch (Exception e) {
				System.out.println("Invalid input try with another one !!");
				System.out.println(e.getMessage());
			}
		}
		System.out.println("Thank you for using application !!");
		System.out.println("See you soon !!");

	}

}
